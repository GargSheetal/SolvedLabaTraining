/**
 * 
 */
package com.mytravelagencyV2;

/**
 * @author sheetal
 *
 */
public interface IReservation {
	
	void confirmReservation();
	void cancelReservation();	

}

/**
 * 
 */
package com.mytravelagency;

/**
 * @author sheetal
 *
 */
public interface IReservation {
	
	void setCustomer(Customer customer);
	void confirmReservation();
	void cancelReservation();	

}
